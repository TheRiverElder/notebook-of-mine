import React, { ChangeEvent, Component, FormEvent, RefObject } from "react";
import { TextChange } from "../interfaces";

export type Vec2 = [number, number];

interface EditorPageProps {
    fileName: string;
    commitChange: (change: TextChange) => void; // 用于发送变更
    onReceiveChangeListeners: Set<(change: TextChange) => void>; // 用于接收其它客户端的变更
}
 
interface EditorPageState {
    text: string;
    selection: Vec2;
    locked: boolean;
}
 
class EditorPage extends Component<EditorPageProps, EditorPageState> {
    constructor(props: EditorPageProps) {
        super(props);
        this.state = { 
            text: '',
            selection: [0, 0],
            locked: true,
        };
    }

    componentDidMount() {
        this.props.onReceiveChangeListeners.add(this.onReceiveChange);
        this.props.commitChange({ fileName: this.props.fileName, content: null });
    }

    componentWillUnmount() {
        this.props.onReceiveChangeListeners.delete(this.onReceiveChange);
    }

    componentDidUpdate() {
        if (this.needResetSelectionRange) {
            const e = this.iptRef.current;
            if (e) {
                const selection = this.state.selection;
                e.setSelectionRange(...selection);
            }
            this.needResetSelectionRange = false;
        }
    }

    iptRef: RefObject<HTMLTextAreaElement> = React.createRef();

    render() { 
        const s = this.state;

        return (
            <div>
                <textarea
                    ref={ this.iptRef }
                    disabled={ s.locked }
                    onSelect={ this.onSelect }
                    onInput={ this.onInput }
                />
            </div>
        );
    }

    onSelect = (e: ChangeEvent<HTMLTextAreaElement>) => {
        this.setState(() => ({ selection: [e.target.selectionStart, e.target.selectionEnd] }));
    }

    onInput = (e: FormEvent<HTMLTextAreaElement>) => {
        const target = e.currentTarget;
        const selection: Vec2 = [target.selectionStart, target.selectionEnd];
        this.setState(() => ({ selection }));
        // const nativeEvent: InputEvent = e.nativeEvent as InputEvent;
        // switch (nativeEvent.inputType) {
        //     case 'insertText': break;
        // }
        this.props.commitChange({ fileName: this.props.fileName, content: this.iptRef.current?.value || '' });
    } 

    getSelection(): Vec2 {
        const e = this.iptRef.current;
        if (e) {
            return [e.selectionStart, e.selectionEnd];
        } else return [0, 0];
    }

    needResetSelectionRange = false;

    onReceiveChange = (change: TextChange) => {
        this.needResetSelectionRange = true;
        this.setState(s => ({ 
            selection: this.getSelection(), 
            text: change.content || '',
            locked: !(s.locked || typeof change.content === 'string'),
        }));
        const e = this.iptRef.current;
        if (e) {
            e.value = change.content || '';
        }
    }
}
 
export default EditorPage;