import React from 'react';
import './App.css';
import EditorPage from './components/EditorPage';
import { TextChange } from './interfaces';

interface AppProps {

}

interface AppState {
  fileNames: string[];
}

class App extends React.Component<AppProps, AppState> {
  constructor(props: AppProps) {
    super(props);
    this.state = { fileNames: [] };
  }

  commitQueue: TextChange[] = [];
  webSocket: WebSocket | null = null;
  onReceiveChangeListeners = new Set<(change: TextChange) => void>();

  componentDidMount() {
    this.webSocket = new WebSocket('ws://' + window.location.hostname + ':8081');
    this.webSocket.onmessage = (ev) => {
      const data = ev.data as string;
      const change: TextChange = JSON.parse(data);
      this.onReceiveChangeListeners.forEach(l => l(change));
    }

    this.webSocket.onopen = () => {
      this.commitQueue.forEach(tc => this.commitChange(tc));
    }
  }

  componentWillUnmount() {
    this.webSocket?.close();
  }

  render() {
    return (
      <div className="App">
        <EditorPage
          fileName="test.txt"
          commitChange={ this.commitChange }
          onReceiveChangeListeners={ this.onReceiveChangeListeners }
        />
      </div>
    );
  }

  commitChange = (change: TextChange) => {
    if (this.webSocket) {
      console.log("commitChange", change);
      this.webSocket?.send(JSON.stringify(change));
    } else {
      this.commitQueue.push(change);
    }
  }
}

export default App;
